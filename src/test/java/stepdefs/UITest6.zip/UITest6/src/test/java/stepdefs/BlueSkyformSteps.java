package stepdefs;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class BlueSkyformSteps {
    //step1:Initialize webdriver

    WebDriver driver;
    //Instantiate chrome driver
    @Given("^I navigate to blueskycitadelform site$")
    public void i_navigate_to_blueskycitadelform_site() throws Throwable {

        //step2:set path

       // System.setProperty("webdriver.gecko.driver", "C:\\firefox\\geckodriver-v0.24.0-win64\\geckodriver.exe");
        System.setProperty("webdriver.chrome.driver", "C:\\blueskycitadelnew\\chromedriver_win32\\chromedriver.exe");

       //step3: Instantiate web driver
         driver = new ChromeDriver();
        //driver = new FirefoxDriver();

         //step4: Navigate to URL
        driver.get("http://www.blueskycitadel.com/test-form-for-bluesky-automation-training/");
        driver.manage().window().maximize();


        //throw new PendingException();
    }

    @When("^I enter first name$")
    public void i_enter_first_name() throws Throwable {

        driver.findElement(By.id("nf-field-26")).sendKeys("Nike");
        //throw new PendingException();
    }

    @When("^I enter Last name$")
    public void i_enter_Last_name() throws Throwable {
        driver.findElement(By.id("nf-field-27")).sendKeys("Olapetan");
        //throw new PendingException();
    }

    @When("^I enter email$")
    public void i_enter_email() throws Throwable {
        driver.findElement(By.cssSelector("#nf-field-28")).sendKeys("agboolaadenike88@gmail.com");
        //throw new PendingException();
    }

    @When("^I enter Email Configuration$")
    public void i_enter_Email_Configuration() throws Throwable {
        driver.findElement(By.xpath("//*[@id=\"nf-field-29\"]")).sendKeys("agboolaadenike88@gmail.com");
        //throw new PendingException();
    }

    @When("^Enter Gender Identification$")
    public void enter_Gender_Identification() throws Throwable {
        driver.findElement(By.id("nf-field-30")).sendKeys("Female");
        //throw new PendingException();
    }

    @When("^I send Age (\\d+)-(\\d+)$")
    public void i_send_Age(int arg1, int arg2) throws Throwable {
        driver.findElement(By.xpath("//*[@id=\"nf-field-31-1\"]")).click();
        //throw new PendingException();
    }

    @When("^I click on submit button$")
    public void i_click_on_submit_button() throws Throwable {
        driver.findElement(By.id("nf-field-37")).click();
        //throw new PendingException();
    }

    @Then("^the form is submitted$")
    public void the_form_is_submitted() throws Throwable {
        // Write code here that turns the phrase above into concrete actions
        //throw new PendingException();
    }

}
